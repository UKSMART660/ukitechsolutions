'use strict';
require('dotenv').config();
const readline = require('readline');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL && /sslmode=require/.test(process.env.DATABASE_URL) ? { rejectUnauthorized: true } : undefined });
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(resolve => rl.question(q, resolve));
function askHidden(prompt) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
      rl.question(prompt + ' (input may be visible in this terminal): ', resolve);
      return;
    }
    process.stdout.write(prompt);
    let value = '';
    const stdin = process.stdin;
    const finish = (err) => { stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData); process.stdout.write('\n'); err ? reject(err) : resolve(value); };
    const onData = chunk => {
      const key = chunk.toString('utf8');
      if (key === '\u0003') return finish(new Error('Cancelled.'));
      if (key === '\r' || key === '\n') return finish();
      if (key === '\u007f' || key === '\b') value = value.slice(0, -1);
      else if (!key.startsWith('\u001b') && key >= ' ') value += key;
    };
    stdin.setRawMode(true); stdin.resume(); stdin.on('data', onData);
  });
}
(async () => {
  try {
    if (!process.env.DATABASE_URL) throw new Error('Set DATABASE_URL in .env first.');
    const username = (await ask('Admin username (3–80 characters): ')).trim();
    const password = await askHidden('Admin password (minimum 14 characters; input hidden): ');
    if (!/^[a-zA-Z0-9._-]{3,80}$/.test(username)) throw new Error('Username must be 3–80 characters and use letters, numbers, dot, underscore or hyphen.');
    if (password.length < 14) throw new Error('Password must be at least 14 characters long.');
    await pool.query(`CREATE TABLE IF NOT EXISTS admin_users (id BIGSERIAL PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), last_login TIMESTAMPTZ)`);
    const hash = await bcrypt.hash(password, 12);
    await pool.query('INSERT INTO admin_users (username,password_hash) VALUES ($1,$2) ON CONFLICT (username) DO UPDATE SET password_hash=EXCLUDED.password_hash', [username,hash]);
    console.log(`Admin account '${username}' saved. Keep this password private.`);
  } catch (e) { console.error(`Could not create admin: ${e.message}`); process.exitCode = 1; }
  finally { rl.close(); await pool.end(); }
})();
