'use strict';
require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const { z } = require('zod');

const app = express();
const port = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && (!process.env.DATABASE_URL || !process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error('Production requires DATABASE_URL and SESSION_SECRET (at least 32 characters).');
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL && /sslmode=require/.test(process.env.DATABASE_URL) ? { rejectUnauthorized: true } : undefined, max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000 });
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(48).toString('base64');

app.disable('x-powered-by');
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://cdnjs.cloudflare.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com', 'https://cdnjs.cloudflare.com', 'data:'], imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"] } } }));
app.use(express.json({ limit: '12kb', type: ['application/json'] }));
app.use(express.urlencoded({ extended: false, limit: '12kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'ukitech.sid', secret: sessionSecret, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProduction, sameSite: 'strict', maxAge: 1000 * 60 * 60 * 4 }
}));

const contactLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many messages from this connection. Please wait and try again, or contact us by phone/WhatsApp.' } });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false, message: 'Too many login attempts. Please wait 15 minutes.' });
const contactSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160),
  topic: z.string().trim().min(1).max(80),
  message: z.string().trim().min(10).max(2000),
  website: z.string().max(0).optional().default('')
}).strict();
const escapeHtml = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const csrfToken = (req) => { if (!req.session.csrf) req.session.csrf = crypto.randomBytes(32).toString('hex'); return req.session.csrf; };
function csrfGuard(req, res, next) {
  const token = req.body && req.body._csrf;
  if (!token || !req.session.csrf || Buffer.byteLength(String(token)) !== Buffer.byteLength(String(req.session.csrf)) || !crypto.timingSafeEqual(Buffer.from(String(token)), Buffer.from(String(req.session.csrf)))) return res.status(403).send('Request expired or invalid. Reload the page and try again.');
  next();
}
function requireAdmin(req, res, next) { if (!req.session.adminId) return res.redirect('/admin/login'); next(); }
function page(title, body) { return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>${escapeHtml(title)} | UKITECHSOLUTIONS Admin</title><style>body{font:16px system-ui;background:#0b1020;color:#f2f5ff;margin:0;padding:24px}main{max-width:1100px;margin:auto}a{color:#42d9ff}input,select,textarea{box-sizing:border-box;width:100%;padding:11px;margin:6px 0 14px;background:#121c33;border:1px solid #35405b;border-radius:8px;color:#fff}button{padding:10px 14px;border:0;border-radius:8px;background:#42d9ff;color:#07101c;font-weight:700;cursor:pointer}table{width:100%;border-collapse:collapse;background:#121c33}th,td{text-align:left;padding:12px;border-bottom:1px solid #35405b;vertical-align:top}small,.muted{color:#aab5ce}.card{max-width:460px;margin:7vh auto;padding:25px;background:#121c33;border:1px solid #35405b;border-radius:16px}.message{white-space:pre-wrap;overflow-wrap:anywhere;max-width:420px}.bar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px}.actions{display:flex;gap:8px;align-items:center}.danger{background:#ffb4b4}.notice{padding:12px;border:1px solid #42d9ff;border-radius:8px;margin:14px 0}form.inline{display:inline} @media(max-width:760px){body{padding:12px;overflow-x:auto}table{font-size:13px}th,td{padding:8px}}</style></head><body><main>${body}</main></body></html>`; }

async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS contact_messages (
    id BIGSERIAL PRIMARY KEY, name VARCHAR(80) NOT NULL, email VARCHAR(160) NOT NULL,
    topic VARCHAR(80) NOT NULL, message TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'new' CHECK (status IN ('new','read','replied','archived')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), ip_hash CHAR(64)
  )`);
  await pool.query('CREATE INDEX IF NOT EXISTS contact_messages_created_at_idx ON contact_messages (created_at DESC)');
  await pool.query(`CREATE TABLE IF NOT EXISTS admin_users (
    id BIGSERIAL PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL, password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), last_login TIMESTAMPTZ
  )`);
}

app.get('/healthz', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }
  catch (_) { res.status(503).json({ ok: false, database: 'unavailable' }); }
});

// Static public pages. API/admin routes are registered first to avoid exposing admin internals.
app.post('/api/contact', contactLimiter, async (req, res) => {
  const parsed = contactSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Please check your name, email, topic, and message (10–2,000 characters).' });
  const { name, email, topic, message, website } = parsed.data;
  if (website) return res.status(400).json({ error: 'Invalid submission.' });
  const ip = String(req.ip || '').slice(0, 100);
  const ipHash = crypto.createHash('sha256').update(`${process.env.IP_HASH_SALT || sessionSecret}:${ip}`).digest('hex');
  let saved;
  try {
    saved = await pool.query('INSERT INTO contact_messages (name,email,topic,message,ip_hash) VALUES ($1,$2,$3,$4,$5) RETURNING id,created_at', [name, email, topic, message, ipHash]);
  } catch (err) {
    console.error('Contact database insert failed:', err.message);
    return res.status(503).json({ error: 'The contact service is temporarily unavailable. Please call or WhatsApp us instead.' });
  }
  let emailSent = false;
  const smtpReady = process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.CONTACT_EMAIL && process.env.FROM_EMAIL;
  if (smtpReady) {
    try {
      const transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: String(process.env.SMTP_SECURE).toLowerCase() === 'true', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
      await transporter.sendMail({ from: process.env.FROM_EMAIL, to: process.env.CONTACT_EMAIL, replyTo: email, subject: `UKITECHSOLUTIONS enquiry: ${topic}`, text: `New contact message #${saved.rows[0].id}\nName: ${name}\nEmail: ${email}\nTopic: ${topic}\n\n${message}` });
      emailSent = true;
    } catch (err) { console.error('SMTP notification failed; message remains stored:', err.message); }
  }
  res.status(201).json({ message: emailSent ? 'Thank you. Your message has been saved and an email notification was sent.' : 'Thank you. Your message has been saved on the website server. Email notification is not configured or is temporarily unavailable.', id: saved.rows[0].id, emailNotification: emailSent ? 'sent' : 'not-sent' });
});

app.get('/admin/login', (req, res) => {
  if (req.session.adminId) return res.redirect('/admin');
  const notice = req.query.error ? '<p class="notice">Login failed. Check your details and try again.</p>' : '';
  res.type('html').send(page('Admin login', `<section class="card"><h1>UKITECHSOLUTIONS Admin</h1><p class="muted">Sign in to manage contact enquiries.</p>${notice}<form method="post" action="/admin/login"> <input type="hidden" name="_csrf" value="${escapeHtml(csrfToken(req))}"><label>Username</label><input name="username" autocomplete="username" maxlength="80" required><label>Password</label><input name="password" type="password" autocomplete="current-password" required><button type="submit">Sign in</button></form><p><a href="/">← Back to website</a></p></section>`));
});
app.post('/admin/login', loginLimiter, csrfGuard, async (req, res) => {
  const username = String(req.body.username || '').trim().slice(0, 80);
  const password = String(req.body.password || '');
  try {
    const result = await pool.query('SELECT id,username,password_hash FROM admin_users WHERE username=$1', [username]);
    const admin = result.rows[0];
    if (!admin || !(await bcrypt.compare(password, admin.password_hash))) return res.redirect('/admin/login?error=1');
    await pool.query('UPDATE admin_users SET last_login=NOW() WHERE id=$1', [admin.id]);
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.adminId = admin.id; req.session.adminUsername = admin.username; req.session.csrf = crypto.randomBytes(32).toString('hex');
    res.redirect('/admin');
  } catch (err) { console.error('Admin login failed:', err.message); res.status(503).send('Admin service unavailable. Check database configuration.'); }
});
app.get('/admin', requireAdmin, async (req, res) => {
  const status = ['new','read','replied','archived'].includes(req.query.status) ? req.query.status : 'all';
  try {
    const result = status === 'all' ? await pool.query('SELECT id,name,email,topic,message,status,created_at FROM contact_messages ORDER BY created_at DESC LIMIT 250') : await pool.query('SELECT id,name,email,topic,message,status,created_at FROM contact_messages WHERE status=$1 ORDER BY created_at DESC LIMIT 250', [status]);
    const rows = result.rows.map(m => `<tr><td>#${m.id}<br><small>${escapeHtml(new Date(m.created_at).toLocaleString())}</small></td><td>${escapeHtml(m.name)}<br><a href="mailto:${escapeHtml(m.email)}">${escapeHtml(m.email)}</a></td><td>${escapeHtml(m.topic)}</td><td><div class="message">${escapeHtml(m.message)}</div></td><td><form method="post" action="/admin/messages/${m.id}/status"><input type="hidden" name="_csrf" value="${escapeHtml(csrfToken(req))}"><select name="status">${['new','read','replied','archived'].map(v=>`<option ${v===m.status?'selected':''} value="${v}">${v}</option>`).join('')}</select><button type="submit">Update</button></form><form class="inline" method="post" action="/admin/messages/${m.id}/delete"><input type="hidden" name="_csrf" value="${escapeHtml(csrfToken(req))}"><button class="danger" type="submit">Delete</button></form></td></tr>`).join('');
    const filter = `<form method="get" action="/admin"><label for="status">Filter status</label> <select id="status" name="status"><option value="all" ${status==='all'?'selected':''}>All messages</option>${['new','read','replied','archived'].map(v=>`<option value="${v}" ${status===v?'selected':''}>${v}</option>`).join('')}</select><button type="submit">Filter</button></form>`;
    res.type('html').send(page('Enquiries', `<div class="bar"><div><h1>Contact enquiries</h1><p class="muted">Signed in as ${escapeHtml(req.session.adminUsername)} · latest 250 messages</p></div><form method="post" action="/admin/logout"><input type="hidden" name="_csrf" value="${escapeHtml(csrfToken(req))}"><button type="submit">Sign out</button></form></div>${filter}<p>${result.rowCount} message(s) shown.</p><table><thead><tr><th>Received</th><th>Customer</th><th>Topic</th><th>Message</th><th>Manage</th></tr></thead><tbody>${rows || '<tr><td colspan="5">No messages found.</td></tr>'}</tbody></table><p class="muted">Keep administrator credentials private. Use HTTPS in production.</p>`));
  } catch (err) { console.error('Admin dashboard failed:', err.message); res.status(503).send('Unable to load dashboard. Check database configuration.'); }
});
app.post('/admin/messages/:id/status', requireAdmin, csrfGuard, async (req, res) => {
  const id = Number(req.params.id); const status = String(req.body.status || '');
  if (!Number.isSafeInteger(id) || id < 1 || !['new','read','replied','archived'].includes(status)) return res.status(400).send('Invalid message or status.');
  await pool.query('UPDATE contact_messages SET status=$1 WHERE id=$2', [status,id]); res.redirect('/admin');
});
app.post('/admin/messages/:id/delete', requireAdmin, csrfGuard, async (req, res) => {
  const id = Number(req.params.id); if (!Number.isSafeInteger(id) || id < 1) return res.status(400).send('Invalid message ID.');
  await pool.query('DELETE FROM contact_messages WHERE id=$1', [id]); res.redirect('/admin');
});
app.post('/admin/logout', requireAdmin, csrfGuard, (req, res, next) => req.session.destroy(err => { if (err) return next(err); res.clearCookie('ukitech.sid'); res.redirect('/admin/login'); }));

app.use((req, res, next) => { if (/^\/(server|node_modules)(\/|$)/i.test(req.path) || /^\/(package\.json|package-lock\.json|Dockerfile|render\.yaml|DEPLOYMENT\.md|README\.md|\.env(?:\..*)?)$/i.test(req.path)) return res.status(404).send('Not found.'); next(); });
app.use(express.static(path.join(__dirname, '..'), { index: 'index.html', dotfiles: 'deny', setHeaders(res, filePath) { if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache'); } }));
app.use((req, res) => { if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Endpoint not found.' }); res.status(404).sendFile(path.join(__dirname, '..', '404.html'), err => { if (err) res.status(404).send('Page not found.'); }); });
app.use((err, _req, res, _next) => { console.error('Unhandled server error:', err.message); if (res.headersSent) return; res.status(500).json({ error: 'An unexpected server error occurred.' }); });

initDb().then(() => {
  app.listen(port, () => console.log(`UKITECHSOLUTIONS listening on port ${port}; public website, contact API and admin routes are configured.`));
}).catch(err => { console.error('Database initialization failed:', err.message); process.exit(1); });
process.on('SIGTERM', async () => { await pool.end(); process.exit(0); });
