# UKITECHSOLUTIONS backend

## Routes
- `POST /api/contact`: validates and stores enquiries in PostgreSQL; sends an email notification only when SMTP environment variables are configured and SMTP succeeds.
- `/admin/login` and `/admin`: authenticated admin dashboard; update status or delete enquiries.
- `/healthz`: readiness check that verifies database connectivity.

## Security controls
Helmet security headers and CSP, HTTPS-only session cookies in production, PostgreSQL-backed sessions, parameterized SQL, bcrypt password hashes, login/contact rate limits, Zod input validation, HTML output escaping, CSRF checks on admin POST forms, and a honeypot field on public contact submissions. Use a trusted managed PostgreSQL service with TLS and restricted credentials. Back up the database and patch dependencies.

## Important operational notes
The app requires PostgreSQL. It does not bundle a database or automatically create a cloud database. Configure `DATABASE_URL` and `SESSION_SECRET` before startup. SMTP delivery is optional and remains unconfigured until valid provider credentials and a verified sender address are supplied. `npm run create-admin` sets/replaces the password for the entered username; protect access to the deployment shell.
